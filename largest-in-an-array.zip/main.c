/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//write a program to print the largest element in a given array by taking random inputs//


#include <stdio.h>

int main()
{
  int n,i;
  printf("enter the value of n:");
  scanf("%d",&n);
  int a[n],max=a[0];
  printf("Enter the elements:");
  for(int i=0;i<n;i++)
  {
      scanf("%d",&a[i]);
  }
  for(i=1;i<n;i++){
  if(a[i]>max)
  {
      max=a[i];
      printf("%d",max);
  }
  }
    
}